const WebSocket = require("ws");
const wss = new WebSocket.Server({ port: 8080 });

console.log("Server running on ws://localhost:8080");

let waiting = null; // player waiting for a game
let games = [];     // active games

function checkWin(board) {
  const lines = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  for (const [a,b,c] of lines) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return board.every(v => v) ? "draw" : null;
}

wss.on("connection", (ws) => {
  if (!waiting) {
    waiting = { ws, symbol: "X" };
    ws.send(JSON.stringify({ type: "waiting" }));
  } else {
    // start game
    const playerX = waiting;
    const playerO = { ws, symbol: "O" };
    const game = {
      players: [playerX, playerO],
      board: Array(9).fill(null),
      turn: 0
    };
    games.push(game);
    [playerX, playerO].forEach((p, i) =>
      p.ws.send(JSON.stringify({ type: "start", player: i, board: game.board, turn: game.turn }))
    );
    waiting = null;
  }

  ws.on("message", (raw) => {
    const data = JSON.parse(raw);
    if (data.type !== "move") return;

    const game = games.find(g => g.players.some(p => p.ws === ws));
    if (!game) return;
    const player = game.players.findIndex(p => p.ws === ws);
    if (player !== game.turn) return;
    if (game.board[data.idx]) return;

    game.board[data.idx] = player === 0 ? "X" : "O";

    const result = checkWin(game.board);
    if (result) {
      game.players.forEach(p =>
        p.ws.send(JSON.stringify({ type: "end", board: game.board, result }))
      );
      games = games.filter(g => g !== game);
    } else {
      game.turn = 1 - game.turn;
      game.players.forEach(p =>
        p.ws.send(JSON.stringify({ type: "update", board: game.board, turn: game.turn }))
      );
    }
  });

  ws.on("close", () => {
    if (waiting && waiting.ws === ws) waiting = null;
    games = games.filter(g => {
      if (g.players.some(p => p.ws === ws)) {
        g.players.forEach(p => {
          if (p.ws !== ws) p.ws.send(JSON.stringify({ type: "end", board: g.board, result: "draw" }));
        });
        return false;
      }
      return true;
    });
  });
});

