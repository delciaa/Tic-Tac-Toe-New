const difficultyScreen = document.getElementById('difficulty-screen');
const gameScreen = document.getElementById('game-screen');
const boardEl = document.getElementById('board');
const statusEl = document.getElementById('status');
const restartBtn = document.getElementById('restart');

let board = Array(9).fill(null);
let gameOver = false;
let difficulty = 'medium';

// Difficulty selection
difficultyScreen.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', () => {
    difficulty = btn.dataset.diff;
    difficultyScreen.classList.remove('active');
    gameScreen.classList.add('active');
    startGame();
  });
});

// Start/restart game
restartBtn.addEventListener('click', startGame);

function startGame() {
  board = Array(9).fill(null);
  gameOver = false;
  createBoard();
  statusEl.textContent = "Your turn";
}

function createBoard() {
  boardEl.innerHTML = '';
  board.forEach((_, i) => {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.dataset.index = i;
    cell.addEventListener('click', handlePlayerMove);
    boardEl.appendChild(cell);
  });
}

function handlePlayerMove(e) {
  const idx = e.target.dataset.index;
  if (gameOver || board[idx]) return;

  board[idx] = 'X';
  render();

  if (checkWinner('X')) return endGame('X won!');
  if (!board.includes(null)) return endGame('Draw!');

  statusEl.textContent = "Computer's turn...";
  setTimeout(computerMove, 400);
}

function computerMove() {
  if (gameOver) return;

  let idx;

  if (difficulty === 'easy') {
    idx = randomMove(); // fully random
  } else if (difficulty === 'medium') {
    idx = Math.random() < 0.3 ? randomMove() : bestMove(board);
  } else {
    idx = bestMove(board); // hard
  }

  board[idx] = 'O';
  render();

  if (checkWinner('O')) return endGame('O won!');
  if (!board.includes(null)) return endGame('Draw!');

  statusEl.textContent = "Your turn";
}

function randomMove() {
  const empty = board.map((v,i) => v === null ? i : null).filter(v => v !== null);
  return empty[Math.floor(Math.random() * empty.length)];
}

function render() {
  board.forEach((val, i) => boardEl.children[i].textContent = val || '');
}

function checkWinner(player) {
  const wins = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  return wins.some(([a,b,c]) => board[a] === player && board[b] === player && board[c] === player);
}

function endGame(msg) {
  gameOver = true;
  statusEl.textContent = msg;
}

// Minimax AI for Medium/Hard
function bestMove(b) {
  let bestScore = -Infinity;
  let move;
  for (let i = 0; i < 9; i++) {
    if (!b[i]) {
      b[i] = 'O';
      let score = minimax(b, 0, false);
      b[i] = null;
      if (score > bestScore) {
        bestScore = score;
        move = i;
      }
    }
  }
  return move;
}

function minimax(b, depth, isMaximizing) {
  const winner = checkWinner('O') ? 'O' : checkWinner('X') ? 'X' : null;
  if (winner === 'O') return 10 - depth;
  if (winner === 'X') return depth - 10;
  if (!b.includes(null)) return 0;

  if (isMaximizing) {
    let best = -Infinity;
    for (let i = 0; i < 9; i++) {
      if (!b[i]) {
        b[i] = 'O';
        best = Math.max(best, minimax(b, depth+1, false));
        b[i] = null;
      }
    }
    return best;
  } else {
    let best = Infinity;
    for (let i = 0; i < 9; i++) {
      if (!b[i]) {
        b[i] = 'X';
        best = Math.min(best, minimax(b, depth+1, true));
        b[i] = null;
      }
    }
    return best;
  }
}


